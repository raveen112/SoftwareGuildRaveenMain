package com.example.supersightings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupersightingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
